class stack 
{
    int a[]=new int[10];
    int top;
    stack()
    {
        top=-1;
    }
    void push(int d)
    {
        if(top==9)
        System.out.println("stack is full");
        else
            a[++top]=d;
        
    }
    void dis()
    {
        int t=top;
        while(t!=-1)
        {
            System.out.print(a[t--]+" ");
        }
    }
    void pop()
    {
        if(top==-1)
        System.out.println("stack is empty");
        else
        top--;
    }
    int peak()
    {
        return a[top];
    }
}
public class Main
{
	public static void main(String[] args) {
    stack s=new stack();
    s.push(10);
    s.push(1);
    s.push(45);
    s.push(89);
    s.dis();
    s.pop();
    System.out.println("\nafter pop");
    s.dis();
    System.out.println("\npeak element is"+":"+s.peak());
	}
}
