class stack 
{
    int a[]=new int[10];
    int top;
    stack()
    {
        top=-1;
    }
    void push(int d)
    {
        if(top==9)
        System.out.println("stack is full");
        else
            a[++top]=d;
        
    }
    void dis()
    {
        while(top!=-1)
        {
            System.out.print(a[top--]+" ");
        }
    }
    void peek()
    {
        System.out.println(a[top]);
    }
    void pop()
    {
        top=top-1;
        while(top!=-1)
        System.out.println(a[top--]);
    }
}
public class Main
{
	public static void main(String[] args) {
    stack s=new stack();
    s.push(10);
    s.push(1);
    s.push(45);
    s.push(89);
    /****
    s.peek();
    s.pop();
    s.dis();
    
    ****/
    
	}
}
