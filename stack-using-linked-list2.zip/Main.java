import java.util.*;
public class Main
{
    static class node 
    {
        int data;
        node next;
        node(int d)
        {
            data=d;
            next=null;
        }
    }
    static node top=null;
    static void push(int d)
    {
        node n=new node(d);
        if(isfull(n))
        {
        System.out.println("Heap overflow");
        return;
        }
        n.next=top;
        top=n;
    }
    static boolean isfull(node n)
    {
        return n==null;
    }
    static void pop()
    {
        if(isempty())
        System.out.println("stack underflow");
        else
        top=top.next;
    }
    static boolean isempty()
    {
        return top==null;
    }
    static void dis()
    {
        node temp=top;
        while(temp!=null)
        {
            System.out.println(temp.data);
            temp=temp.next;
        }
    }
    static int peek()
    {
        return top.data;
    }
	public static void main(String[] args) {
	    Scanner s=new Scanner(System.in);
	    int b=1;
	    while(b!=0)
	    {
	    System.out.println("enter the choice \n 1-push\n 2-pop\n 3-peek \n 4-dis \n 5-exit ");    
	    int c=s.nextInt();
	    switch(c)
	    {
	        case 1:
	            push(s.nextInt());
	            break;
	        case 2:
	            pop();
	            break;
	        case 3:
	            System.out.println(peek());
	            break;
	        case 4:
	            dis();
	            break;
	        case 5:
	            b=0;
	    }
	    }
		
	}
}
